let test = () => { console.log('test') }
import './src/assets/scss/app.scss';
import './src/assets/scss/app2.scss';