const path = require('path');


const CleanWebpackPlugin = require('clean-webpack-plugin');
const ExtractTextWebpackPlugin = require('extract-text-webpack-plugin');

module.exports = {
    entry: './app.js',
    output: {
        path: path.resolve(__dirname) + '/dist',
        filename: 'app.js',
    },

    module: {
        rules: [{
                test: /\.js$/,
                use: [{
                    loader: 'babel-loader',
                }],
                exclude: '/node_modules/',
            },
            {
                test: /\.s?css$/,
                use: ExtractTextWebpackPlugin.extract({
                    fallback: {
                        loader: 'style-loader',
                    },

                    use: [{
                            loader: 'css-loader',
                        },

                        {
                            loader: 'postcss-loader',
                            options: {
                                ident: 'postcss',
                                plugins: [
                                    require('postcss-cssnext')(),
                                ]
                            },

                        },

                        {
                            loader: 'sass-loader',
                        },
                    ],
                }),
            }

        ]
    },

    plugins: [
        new CleanWebpackPlugin(),
        new ExtractTextWebpackPlugin({
            filename: 'app.css',
            allChunks: true,
        }),
    ],

    mode: 'development',

}