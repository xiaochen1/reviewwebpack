export const sayA = () => { console.log('AA') }
export const sayB = () => { console.log('BB') }
export const sayC = () => { console.log('CC') }