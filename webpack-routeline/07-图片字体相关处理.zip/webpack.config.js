const path = require('path');


const CleanWebpackPlugin = require('clean-webpack-plugin');
const ExtractTextWebpackPlugin = require('extract-text-webpack-plugin');
const PurifyCssWebpack = require("purifycss-webpack");
const glob = require("glob-all");

module.exports = {
    // entry: './app.js',
    // output: {
    //     path: path.resolve(__dirname) + '/dist',
    //     filename: 'app.js',
    // },
    entry: {
        pageA: './src/assets/js/pageA',
        pageB: './src/assets/js/pageB',
    },

    output: {
        path: path.resolve(__dirname) + '/dist',
        publicPath: './',
        filename: '[name].bundle.js',
        chunkFilename: '[name].chunk.js',
    },

    module: {
        rules: [{
                test: /\.js$/,
                use: [{
                    loader: 'babel-loader',
                }],
                exclude: '/node_modules/',
            },
            {
                test: /\.s?css$/,
                use: ExtractTextWebpackPlugin.extract({
                    fallback: {
                        loader: 'style-loader',
                    },

                    use: [{
                            loader: 'css-loader',
                            options: {
                                // importLoaders: 1 // 0 => no loaders (default); 1 => postcss-loader; 2 => postcss-loader, sass-loader
                            }
                        },

                        {
                            loader: 'postcss-loader',
                            options: {
                                ident: 'postcss',
                                plugins: [
                                    // require('postcss-cssnext')(),
                                    require('autoprefixer')({
                                        browsers: [
                                            "last 2 versions",
                                            "defaults",
                                            "not ie < 11",
                                            "last 2 versions",
                                            "> 1%",
                                            "iOS 7",
                                            "last 3 iOS versions"
                                        ]
                                    }),
                                ]
                            },
                        },

                        {
                            loader: 'sass-loader',
                        },


                    ],
                }),
            },

            {
                test: /\.(jpg|jpeg|png|gif)$/,
                use: [{
                        loader: "file-loader",
                        options: {
                            name: "[name].[ext]",
                            outputPath: "img/",
                            publicPath: "",
                            useRelativePath: true,
                        }
                    },

                    // url-loader  ==  file-loader + 图片base64编码
                    // {
                    //     loader: "url-loader",
                    //     options: {
                    //         name: "[name].[ext]",
                    //         outputPath: "img/",
                    //         limit: 1024 * 500,
                    //     }
                    // },

                    {
                        loader: 'image-webpack-loader',
                        options: {
                            mozjpeg: {
                                progressive: true,
                                quality: 65
                            },
                            // optipng.enabled: false will disable optipng
                            optipng: {
                                enabled: false,
                            },
                            pngquant: {
                                quality: '65-90',
                                speed: 4
                            },
                            gifsicle: {
                                interlaced: false,
                            },
                            // the webp option will enable WEBP
                            webp: {
                                quality: 75
                            }
                        }
                    },


                ]
            },

            {
                test: /\.(eot|svg|ttf|woff|woff2)$/,
                use: [{
                    loader: 'url-loader',
                    options: {
                        name: "[name]-[hash:5].min.[ext]",
                        limit: 1024 * 5, // fonts file size <= 5KB, use 'base64'; else, output svg file
                        outputPath: "fonts/",
                        publicPath: "fonts/",
                    }
                }]
            },
        ]
    },

    plugins: [
        new CleanWebpackPlugin(),
        new ExtractTextWebpackPlugin({
            filename: 'app.css',
            // filename: "[name].css?[hash:8]"
        }),

        new PurifyCssWebpack({
            paths: glob.sync([
                // 要做CSS Tree Shaking的路径文件
                path.resolve(__dirname, "./*.html"),
                path.resolve(__dirname, "./src/assets/js/*.js"),
            ])
        }),
    ],


    optimization: {
        minimize: true,
        splitChunks: {
            //启动代码分割,不写有默认配置项
            chunks: 'all', //参数all/initial/async，只对所有/同步/异步进行代码分割
            minSize: 10, //大于10字节才会对代码分割
            maxSize: 0,
            minChunks: 1, //打包生成的文件，当一个模块至少用多少次时才会进行代码分割
            maxAsyncRequests: 5, //同时加载的模块数最多是5个
            maxInitialRequests: 3, //入口文件最多3个模块会做代码分割，否则不会
            automaticNameDelimiter: '~', //文件自动生成的连接符
            name: true,
            cacheGroups: {
                // 第三方代码
                vendor: {
                    test: /[\\/]node_modules[\\/]/,
                    priority: -10, //谁优先级大就把打包后的文件放到哪个组 (建议 比默认值0 小)
                    name: 'vendor', // name 结合 output中的chunkFilename格式化输出文件名，得到最终打包生成的文件名
                    // filename: 'vendor.chunk.js', // 直接定义打包后的文件名
                },

                // 业务代码
                common: {
                    minChunks: 2,
                    priority: -20, // (建议 比默认值0 小)
                    reuseExistingChunk: true, //模块已经被打包过了，就不用再打包了，复用之前的就可以
                    name: 'common', //打包之后的文件名
                    // filename: 'common.chunk.js', // 直接定义打包后的文件名
                },

                // default: {
                //     minChunks: 2,
                //     priority: -30,
                //     reuseExistingChunk: true, //模块已经被打包过了，就不用再打包了，复用之前的就可以
                //     filename: 'common.chunk.js' //打包之后的文件名   
                // }

            },
        },

    },
    mode: 'production',
}