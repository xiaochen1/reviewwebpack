// import './subPageA'
// import './subPageB'

// 由于 subPageA和subPageB中都引入了 common, 所以subPageA和subPageB打包后的目标文件中都有common
// 相关代码， 为了减少这部分公共的代码， 故而提前将这部分代码引入
// require.include('./common');

// // 直接引入， 会将lodash 直接打包到目标文件中
// // import * as _ from 'lodash'

// // 异步加载， webpack 自动会将lodash 提取出来,
// //若output中的chunkFilename: '[name].chunk.js',, 则生成的文件为   name.chunk.js
// require.ensure(['lodash'], () => {
//     let _ = require('lodash');
//     _.join(["1", "2"], "3");
// }, 'bundleLodash');
// // 生成  vendors~bundleLodash.chunk.js
// // 因为output字段中的filename: '[name].chunk.js',

// require.ensure(['./subPageA'], () => {
//     let subPageA = require('./subPageA');
//     // console.log(subPageA);
// }, 'bundleSubPageA');

// require.ensure(['./subPageB'], () => {
//     let subPageB = require('./subPageB');
//     // console.log(subPageB);
// }, 'bundleSubPageB');

// export default 'pageA';


import subPageA from './subPageA'
import subPageB from './subPageB'
import * as _ from 'lodash'
import '../scss/app.scss'

// 单引入但是不使用的话， js的tree-shaking 在打包后的目标文件中会自动去除掉多余的代码，
console.log(subPageA, subPageB);
console.log(_.join(["1", "2"], "3"));
export default 'pageA';