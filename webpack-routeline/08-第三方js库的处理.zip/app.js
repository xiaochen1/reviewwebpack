// let test = () => { console.log('test') }
// import './src/assets/scss/app.scss';
// import './src/assets/scss/app2.scss';
// import { sayA, sayB, sayC } from './src/assets/js/common.js';
// sayA();