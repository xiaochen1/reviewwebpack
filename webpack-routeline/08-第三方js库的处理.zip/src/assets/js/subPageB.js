import common from './common'
console.log(common);
export default 'subPageB'