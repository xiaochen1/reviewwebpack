import common from './common'
console.log(common);
$("#app").append($("<h3>hahah</h3>"));
export default 'subPageA'