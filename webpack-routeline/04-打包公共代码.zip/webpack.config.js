const path = require('path');


const CleanWebpackPlugin = require('clean-webpack-plugin');
const ExtractTextWebpackPlugin = require('extract-text-webpack-plugin');

module.exports = {
    // entry: './app.js',
    // output: {
    //     path: path.resolve(__dirname) + '/dist',
    //     filename: 'app.js',
    //     filename: './src/js/pageA.js',
    // },
    entry: {
        pageA: './src/assets/js/pageA',
        pageB: './src/assets/js/pageB',
    },

    output: {
        path: path.resolve(__dirname) + '/dist',
        filename: '[name].bundle.js',
        chunkFilename: '[name].chunk.js',
    },

    module: {
        rules: [{
                test: /\.js$/,
                use: [{
                    loader: 'babel-loader',
                }],
                exclude: '/node_modules/',
            },
            {
                test: /\.s?css$/,
                use: ExtractTextWebpackPlugin.extract({
                    fallback: {
                        loader: 'style-loader',
                    },

                    use: [{
                            loader: 'css-loader',
                        },

                        {
                            loader: 'postcss-loader',
                            options: {
                                ident: 'postcss',
                                plugins: [
                                    require('postcss-cssnext')(),
                                ]
                            },

                        },

                        {
                            loader: 'sass-loader',
                        },
                    ],
                }),
            }

        ]
    },

    plugins: [
        new CleanWebpackPlugin(),
        new ExtractTextWebpackPlugin({
            filename: 'app.css',
        }),
    ],

    optimization: {
        minimize: true,
        splitChunks: {
            // chunks: 'async',
            // minSize: 0,
            // maxSize: 0,
            // minChunks: 1,
            // maxAsyncRequests: 5,
            // maxInitialRequests: 3,
            // automaticNameDelimiter: '~',
            // name: true,
            cacheGroups: {
                // 业务公共代码
                common: {
                    // filename: '[name].common.js'
                    name: 'common',
                    chunks: 'all',
                    minChunks: 1,
                    minSize: 0,
                    priority: 0,
                },

                // 第三方代码
                vendors: {
                    test: /[\\/]node_modules[\\/]/,
                    minChunks: 1,
                    priority: 10
                },
            },
        },

    },

    mode: 'production',

}