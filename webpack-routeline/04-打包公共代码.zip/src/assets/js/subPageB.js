import './common'
export default 'subPageB'