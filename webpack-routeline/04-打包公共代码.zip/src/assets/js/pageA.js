import './subPageA'
import './subPageB'

export default 'pageA';