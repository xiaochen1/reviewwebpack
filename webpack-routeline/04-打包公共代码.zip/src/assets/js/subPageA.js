import './common'
export default 'subPageA'