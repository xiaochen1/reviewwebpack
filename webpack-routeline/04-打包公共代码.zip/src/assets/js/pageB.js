import './subPageA'
import './subPageB'
export default 'pageB';